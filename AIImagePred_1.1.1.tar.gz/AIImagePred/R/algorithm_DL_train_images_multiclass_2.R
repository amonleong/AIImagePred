#14-6-2019
################################################################################
#deep learning: TRAIN IMAGES AND SAVE A MODEL DL
#https://rstudio-pubs-static.s3.amazonaws.com/236125_e0423e328e4b437888423d3821626d92.html
###############################################################################

#toni monleon (26-08-2019)

#########################################################################################
# Algorithm to train images in the DL algorithm and save its characteristics
# Multiclass classification
# Check model (cross-validation) and save model
#########################################################################################
#accept multiple clases

#' Algorithm to train images using Deep Learning and save its characteristics using a model (Multiple classes)
#'
#' @param dir.imag.training vector X for the function weibull4p
#' @param dictionary=c(plastic=0, sin=1) vector Y for the function weibull4p
#' @param size_foto picture size, defect size_foto=2
#' @param check.accuracy option to check accuracy of classification, defect check.accuracy = T
#' @param Do.saveRDS save pictures classes using RDS files, defect  Do.saveRDS=T
#' @param Do.save.model=T save DL-model with method to classify picures, defect Do.save.model=T
#' @param percent.CV percentage of pictures used for training, defect percent.CV=0.9
#' @param num.round = 250 number of iterations for the numerical DL method used, defect num.round = 250
#' @return Model DL, cross-validation classification matrix, classification statistics
#' @export
#' #'
#' @examples
#' #Functional example only for tiger and culex mosquitoes and not-mosquitoes: 3 classes(CULEX, TIGER AND WITHOUT). GET IMAGE DIRECTORY "aedes_culex_clases_train" FROM MOSQUITO IN RESEARCHGATE https://www.researchgate.net/publication/335444848_mosquitoes_train_test_images_for_deep_learning_algorithm_Training_and_test_set
#' #directory with the images of the training. Its features have been extracted
#'
#'GET IMAGE DIRECTORY "aedes_culex_clases_train" FROM MOSQUITO IN RESEARCHGATE: https://www.researchgate.net/publication/335444848_mosquitoes_train_test_images_for_deep_learning_algorithm_Training_and_test_set
#'
#'###########################################################################################################
#'###########################################################################################################
#'#1. Obtain Prediction model (DL) with a training set already completed
#'###########################################################################################################
#'###########################################################################################################
#'
#'#######################3 CLASSES training #################################################################################3
#'## example with tiger and culex mosquitoes and others images
#'#' change directory if necessary !!!!!!!!!!!!
#'image_dir_train <- "D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/FRANCESC_LLIMONA_tfm_upc/aedes_culex_clases_train"
#'dictionary<-c(tigre=1, culex=2, sin=3) #set classes and dictionary for classes tiger, culex and others (no mosquitoes)
#'image.trainimages.DL.algorithm_multiclass(dir.imag.training=image_dir_train, dictionary, size_foto=25, Do.saveRDS=T, Do.save.model=T, percent.CV=0.9, check.accuracy = T,  num.round = 250)
#'###########################################################################################################
#'
#'#indica la accuracy:
#'
#' Results obtained for the training set:
#'
#'#[1] "Accuracy table: ----CROSS-VALIDATION( 90 %DATA)-----------------------------------"
#'#predicted_labels
#'#1  2  3
#'#1 31  0  0
#'#2  3 13  0
#'#3  0  0 15
#'#[1] "% accuracy total ( 90 %, Cross-validation)="
#'#[1] 0.9516129
#'#[1] "Accuracy table: ----CROSS-VALIDATION( 10 %DATA)-----------------------------------"
#'#predicted_labels
#'#1 2 3
#'#1 3 1 0
#'#2 0 1 0
#'#3 0 0 1
#'#[1] "% accuracy total ( 10 %, Cross-validation)="
#'#[1] 0.8333333
#'
#'
#'###########################################################################################################
#'###########################################################################################################
#'#2.Prediction (DL) using a training set (saved DL-model) already performed (Step-1)and with a test set in another directory
#'###########################################################################################################
#'###########################################################################################################

#' change directory if necessary !!!!!!!!!!!!
#' #In this directory you will find the DL-model of the training images saved previosuly:
#' train.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/FRANCESC_LLIMONA_tfm_upc/aedes_culex_clases_train"

#' #In this directory are the images to predict (See RESEARCHGATE) https://www.researchgate.net/publication/335444848_mosquitoes_train_test_images_for_deep_learning_algorithm_Training_and_test_set:
#' predict.test.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/FRANCESC_LLIMONA_tfm_upc/test_imagen_mosquito_tigre"

#' name.files.images<-c("")


#' #################### test prediction ####### DL-model saved = prova_model.RData #####################################################################
#' #prediction of images mosquitoes (images are not divided into multiple images)
#' res.pred.DL.images.test<- split.predict.count.multiclass(train.images.dir, name.files.images, predict.test.images.dir, dictionary=c(tigre=1, culex=2, sin=3),  use.model=T, nom.model.saved = "prova_model.RData", num.round = 250, n.div=1)
#' res.pred.DL.images.test
#'
#' Results of the ptest images prediction using DL
#'
#'#images_names predicted_labels names.dictionary.predicted_labels..
#'#1   culex11_c_1_r_1_nimag1.jpg                2                               culex
#'#2   culex11_c_1_r_1_nimag2.jpg                2                               culex
#'#3   culex51_c_1_r_1_nimag3.jpg                2                               culex
#'#4   culex91_c_1_r_1_nimag4.jpg                2                               culex
#'#5   sin_121_c_1_r_1_nimag5.jpg                3                                 sin
#'#6   sin_131_c_1_r_1_nimag6.jpg                3                                 sin
#'#7   sin_141_c_1_r_1_nimag7.jpg                3                                 sin
#'#8  tigre_1_c_1_r_1_nimag10.jpg                1                               tigre
#'#9  tigre_1_c_1_r_1_nimag11.jpg                1                               tigre
#'#10 tigre_1_c_1_r_1_nimag12.jpg                1                               tigre
#'#11 tigre_1_c_1_r_1_nimag13.jpg                1                               tigre
#'#12  tigre_1_c_1_r_1_nimag8.jpg                1                               tigre
#'#13  tigre_1_c_1_r_1_nimag9.jpg                2                               culex
#'
#'#[[2]][[2]]
#'#[1] "tigre" "culex" "sin"
#'
#'# The resuts ca be different to the above results




#' @references
#' CI Rodríguez-Casado, A Monleon-Getino, M Cubedo, M Ríos- Alcolea. 2017. A Priori Groups Based On Bhattacharyya Distance And Partitioning Around Medoids Algorithm (PAM) With Applications To Metagenomics
#' IOSR Journal of Mathematics 13 (3), 24-32
#'
#'#' Daniel Falbel et al. 2017. Package Keras. R package <https://cran.r-project.org/web/packages/keras/keras.pdf>



image.trainimages.DL.algorithm_multiclass <- function(dir.imag.training, dictionary=c(plastic=0, sin=1), size_foto=25, check.accuracy = T, Do.saveRDS=T, Do.save.model=T, percent.CV=0.9, num.round = 250){

  #dir.imag = donde esta las imagenes de train
  # dir.imag.training= tamano de la foto cuando se extraen sus caracteristicas
  # check the model using DL-> check.accuracy = T
  # Do.saveRDS=T save files with characteristics 25 x 25 or other in a RDS files
  # num.round = 150 # hyperparameter for DL model

  #create a dictionary:
  #eg
  #l <- c(a = 1, b = 7, f = 2)
  #l
  #l[2]
  #names(l)
  #dictionary<-c(plastic=0, sin=1)
  #names(dictionary)

  #chage directory
  setwd(dir.imag.training)


  #extract information from images
  library(EBImage)
  #As a quick example, I will use EBImage to resize the images to 28×28 and turn them into greyscale so that I can load them into R easily. To do so, I will use a function to process the images for cats and dogs separately. Each image will be turned into a vector of length 784, with each element representing the value in a pixel.
  size_foto<- size_foto #25 filas de pixeles
  width <- size_foto
  height <- size_foto
  ## pbapply is a library to add progress bar *apply functions
  ## pblapply will replace lapply
  library(pbapply)
  ##extract_feature <- function(dir_path, width, height, is_class = TRUE, add_label = TRUE) {
  ##  img_size <- width*height
  ##  ## List images in path
  ##  images_names <- list.files(dir_path)
  ##  if (add_label) {
  ##    ## Select only images "class1", "class2"
  ##    aaaa<-cat(names(dictionary)[1], ", ", names(dictionary)[2], sep="")
  ##    images_names <- images_names[grepl(ifelse(is_class, names(dictionary)[1], names(dictionary)[2]), images_names)]
  ##    ## Set label, plastic = 0, sin = 1
  ##    label <- ifelse(is_class, as.numeric(dictionary)[1], as.numeric(dictionary)[2])
  ##  }
  ##  print(paste("Start processing", length(images_names), "images"))
  ##  ## This function will resize an image, turn it into greyscale
  ##  feature_list <- pblapply(images_names, function(imgname) {
  ##    ## Read image
  ##    img <- readImage(file.path(dir_path, imgname))
  ##    ## Resize image
  ##    img_resized <- resize(img, w = width, h = height)
  ##    ## Set to grayscale
  ##    grayimg <- channel(img_resized, "gray")
  ##    ## Get the image as a matrix
  ##    img_matrix <- grayimg@.Data
  ##    ## Coerce to a vector
  ##    img_vector <- as.vector(t(img_matrix))
  ##    return(img_vector)
  ##  })
  ##  ## bind the list of vector into matrix
  ##  feature_matrix <- do.call(rbind, feature_list)
  ##  feature_matrix <- as.data.frame(feature_matrix)
  ##  ## Set names
  ##  names(feature_matrix) <- paste0("pixel", c(1:img_size))
  ##  if (add_label) {
  ##    ## Add label
  ##    feature_matrix <- cbind(label = label, feature_matrix)
  ##  }


  ##  return(feature_matrix)
  ##}

  extract_feature_multiclass <- function(dir_path, width, height, dictionary, add_label = TRUE) {
    img_size <- width*height

    #para cada clase del diccionario
    complete_set.a<-data.frame()
    for(i in 1:length(dictionary)){
      ## List images in path
      images_names <- list.files(dir_path)
      #seleccionar las imagenes segun el diccionario
      #i<-2
      images_names <- images_names[grepl(names(dictionary)[i],images_names)]
      label <- as.numeric(dictionary)[i]
      print(paste("Start processing", length(images_names), "images", ",Class=", names(dictionary)[i]))
      ## This function will resize an image, turn it into greyscale
      feature_list <- pblapply(images_names, function(imgname) {
        ## Read image
        img <- readImage(file.path(dir_path, imgname))
        ## Resize image
        img_resized <- resize(img, w = width, h = height)
        ## Set to grayscale
        grayimg <- channel(img_resized, "gray")
        ## Get the image as a matrix
        img_matrix <- grayimg@.Data
        ## Coerce to a vector
        img_vector <- as.vector(t(img_matrix))
        return(img_vector)
      })
      ## bind the list of vector into matrix
      feature_matrix <- do.call(rbind, feature_list)
      feature_matrix <- as.data.frame(feature_matrix)
      ## Set names
      names(feature_matrix) <- paste0("pixel", c(1:img_size))
      if (add_label) {
        ## Add label
        feature_matrix <- cbind(label = label, feature_matrix)
      }

      if(Do.saveRDS==T){
        saveRDS(feature_matrix, paste(names(dictionary)[i],".rds",sep=""))

      }
      complete_set.a<-rbind( complete_set.a, feature_matrix)

      #View(feature_matrix)
    }

    ##if (add_label) {
    ##  ## Select only images "class1", "class2"
    ##  aaaa<-cat(names(dictionary)[1], ", ", names(dictionary)[2], sep="")
    ##  images_names <- images_names[grepl(ifelse(is_class, names(dictionary)[1], names(dictionary)[2]), images_names)]
    ##  ## Set label, plastic = 0, sin = 1
    ##  label <- ifelse(is_class, as.numeric(dictionary)[1], as.numeric(dictionary)[2])
    ##}
    return(complete_set.a) #toda la matriz de caracteristicas
  }
  #Process plastic and dog images separately and save them into data.frame
  complete_set<-extract_feature_multiclass(dir_path = dir.imag.training, width = width, height = height,dictionary )
  #View(complete_set)
  #class1_data <- extract_feature(dir_path = dir.imag.training, width = width, height = height,is_class = T)
  #class2_data <- extract_feature(dir_path = dir.imag.training, width = width, height = height, is_class = FALSE)
  #dim(class1_data)
  ## [1] 12500   785
  #dim(class2_data)
  ## [1] 12500   785
  #Save the data just in case:

  #save the characteristics of the images
  #if(Do.saveRDS==T){
  #  saveRDS(class1_data, "class1_data.rds")
  #  saveRDS(class2_data, "class2_data.rds")
  #}

  #check the accuracy with the train data:
  if(check.accuracy == T){
    #3 Model Training
    #Data partitions: randomly split 90% of data into training set with equal weights for cats and dogs, and the rest 10% will be used as the test set.

    #si se han salvado-llamar a los ficheros .rds
    #setwd("E:/intercambioconservidorBIOST3/odei/Plastics/train")
    #plastic_data<-readRDS("plastic.rds", refhook = NULL)
    #sin_data<-readRDS("sin.rds", refhook = NULL)
    library(caret)
    ## Bind rows in a single dataset
    #complete_set <- rbind(class1_data, class2_data)
    ## test/training partitions
    training_index <- createDataPartition(complete_set$label, p = percent.CV, times = 1)
    training_index <- unlist(training_index)
    train_set <- complete_set[training_index,]
    dim(train_set)
    ## [1] 22500   785
    test_set <- complete_set[-training_index,]
    dim(test_set)
    ## [1] 2500  785
    #Reshape the data into a proper format required by the model:

    ## Fix train and test datasets
    train_data <- data.matrix(train_set)
    train_x <- t(train_data[, -1])
    train_y <- train_data[,1]
    train_array <- train_x
    dim(train_array) <- c(size_foto, size_foto, 1, ncol(train_x))

    test_data <- data.matrix(test_set)
    test_x <- t(test_set[,-1])
    test_y <- test_set[,1]
    test_array <- test_x
    dim(test_array) <- c(size_foto, size_foto, 1, ncol(test_x))
    #Training the model:

    library(mxnet)
    ## Model
    mx_data <- mx.symbol.Variable('data')
    ## 1st convolutional layer 5x5 kernel and 20 filters.
    conv_1 <- mx.symbol.Convolution(data = mx_data, kernel = c(5, 5), num_filter = 20)
    tanh_1 <- mx.symbol.Activation(data = conv_1, act_type = "tanh")
    pool_1 <- mx.symbol.Pooling(data = tanh_1, pool_type = "max", kernel = c(2, 2), stride = c(2,2 ))
    ## 2nd convolutional layer 5x5 kernel and 50 filters.
    conv_2 <- mx.symbol.Convolution(data = pool_1, kernel = c(5,5), num_filter = 50)
    tanh_2 <- mx.symbol.Activation(data = conv_2, act_type = "tanh")
    pool_2 <- mx.symbol.Pooling(data = tanh_2, pool_type = "max", kernel = c(2, 2), stride = c(2, 2))
    ## 1st fully connected layer
    flat <- mx.symbol.Flatten(data = pool_2)
    fcl_1 <- mx.symbol.FullyConnected(data = flat, num_hidden = 500)
    tanh_3 <- mx.symbol.Activation(data = fcl_1, act_type = "tanh")
    ## 2nd fully connected layer
    fcl_2 <- mx.symbol.FullyConnected(data = tanh_3, num_hidden = 20)
    ## Output
    NN_model <- mx.symbol.SoftmaxOutput(data = fcl_2)

    ## Set seed for reproducibility
    #mx.set.seed(100)

    ## Device used. Sadly not the GPU :-(
    device <- mx.cpu()

    ## Train on 1200 samples
    model <- mx.model.FeedForward.create(NN_model, X = train_array, y = train_y,
                                         ctx = device,
                                         num.round = num.round,
                                         array.batch.size = 100,
                                         learning.rate = 0.025,
                                         momentum = 0.9,
                                         wd = 0.00001,
                                         eval.metric = mx.metric.accuracy,
                                         epoch.end.callback = mx.callback.log.train.metric(100))
    ## Start training with 1 devices
    ## [1] Train-accuracy=0.493973214285715
    ## [2] Train-accuracy=0.492755555555556
    ## [3] Train-accuracy=0.492755555555556
    ## [4] Train-accuracy=0.4932
    ## [5] Train-accuracy=0.495688888888889
    ## [6] Train-accuracy=0.5264
    ## [7] Train-accuracy=0.583644444444444
    ## [8] Train-accuracy=0.6212
    ## [9] Train-accuracy=0.648577777777778
    ## [10] Train-accuracy=0.671822222222222
    ## [11] Train-accuracy=0.692444444444445
    ## [12] Train-accuracy=0.710533333333333
    ## [13] Train-accuracy=0.724622222222222
    ## [14] Train-accuracy=0.735955555555555
    ## [15] Train-accuracy=0.747288888888889
    ## [16] Train-accuracy=0.759111111111111
    ## [17] Train-accuracy=0.772355555555556
    ## [18] Train-accuracy=0.7848
    ## [19] Train-accuracy=0.792133333333334
    ## [20] Train-accuracy=0.803822222222223
    ## [21] Train-accuracy=0.814977777777778
    ## [22] Train-accuracy=0.821822222222223
    ## [23] Train-accuracy=0.825155555555556
    ## [24] Train-accuracy=0.824933333333334
    ## [25] Train-accuracy=0.834044444444444
    ## [26] Train-accuracy=0.827066666666667
    ## [27] Train-accuracy=0.828177777777778
    ## [28] Train-accuracy=0.837644444444445
    ## [29] Train-accuracy=0.848133333333333
    ## [30] Train-accuracy=0.849422222222222
    #After 30 iterations, this model achieves a peak performance of about 85% accuracy. Next let’s see how it performs on the test set.

    ## Test test set (Cross-validation 20%)
    predict_probs <- predict(model, train_array)
    print(paste("Accuracy table: ----CROSS-VALIDATION(", 100*percent.CV, "%DATA)-----------------------------------"))
    #print(predict_probs)
    predicted_labels <- max.col(t(predict_probs)) - 1

    print(table(train_data[, 1], predicted_labels))
    ##    predicted_labels
    ##        0    1
    ##   0 1099  151
    ##   1  470  780
    print(paste("% accuracy total (",100*percent.CV, "%, Cross-validation)="))
    print(sum(diag(table(train_data[, 1], predicted_labels)))/sum(table(train_data[, 1], predicted_labels)))



    ## Test test set (Cross-validation 20%)
    predict_probs <- predict(model, test_array)
    #percent.CV=0.8
    print(paste("Accuracy table: ----CROSS-VALIDATION(", 100-100*percent.CV, "%DATA)-----------------------------------"))
    #print(predict_probs)
    predicted_labels <- max.col(t(predict_probs)) - 1

    print(table(test_data[, 1], predicted_labels))
    ##    predicted_labels
    ##        0    1
    ##   0 1099  151
    ##   1  470  780
    print(paste("% accuracy total (",100-100*percent.CV, "%, Cross-validation)="))
    print(sum(diag(table(test_data[, 1], predicted_labels)))/sum(table(test_data[, 1], predicted_labels)))
    ## [1] 0.7516
    #The model reaches 75% accuracy on the test set. The score is of course a bit mediocre, but it can be easily improved by tuning the model, using more pixels and RGB representation.

    #save the model
    ##pere lopez: como salvar y recuperar el modelo
    ## desar
    if(Do.save.model==T){
      modelr <- mx.serialize(model)
      save(modelr, file="prova_model.RData")
    }



    # table(test_data[, 1], predicted_labels)
    #predicted_labels
    #0  1
    #0  9  3
    #1  4 28
    #> ##    predicted_labels
    #  > ##        0    1
    #  > ##   0 1099  151
    #  > ##   1  470  780
    #  > sum(diag(table(test_data[, 1], predicted_labels)))/sum(table(test_data[, 1], predicted_labels))
    #[1] 0.8409091

    #save(model, file = "model_deep.RData")
    # To load the data again
    #load("model_deep_learning.RData")

    #salvar el objeto model
    #saveRDS(model, "final_model.rds") # no salva el modelo
  }




}




##############################################################
# project UE MEDSEALITTER
#############################################################

#install.packages("drat", repos="https://cran.rstudio.com")
#drat:::addRepo("dmlc")

#cran <- getOption("repos")
#cran["dmlc"] <- "https://s3-us-west-2.amazonaws.com/apache-mxnet/R/CRAN/"
#options(repos = cran)
#install.packages("mxnet",dependencies = T)

#a partir de aqui
#library(mxnet)


## Directory for images (.jpg, .png)
#image_dir <- "C:/Users/Toni/Downloads/dogs-vs-cats-redux-kernels-edition/train"
#image_dir <- "C:/Users/Toni/Downloads/plastic/train"
#image_dir <-"E:/intercambioconservidorBIOST3/odei/Plastics/train"
#image_dir <-"E:/intercambioconservidorBIOST3/odei/Plastics/test"

#########################################################################################################3
# example with plastic - non plastic images
# image_dir_train <- "D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/train"
# dictionary<-c(plastic=0, sin=1) #set classes and dictionary for classes
# image.trainimages.DL.algorithm_binary(dir.imag.training=image_dir_train, dictionary=c(plastic=0, sin=1), size_foto=25, Do.saveRDS=T, check.accuracy = T,  num.round = 150)
###########################################################################################################


#######################3 CLASES #################################################################################3
## example with tiger mosquito and others images
#image_dir_train <- "D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/FRANCESC_LLIMONA_tfm_upc/tres_clases_train"
#dictionary<-c(tigre=1, culex=2, sin=3) #set classes and dictionary for classes
#image.trainimages.DL.algorithm_multiclass(dir.imag.training=image_dir_train, dictionary, size_foto=25, Do.saveRDS=T, Do.save.model=T, percent.CV=0.9, check.accuracy = T,  num.round = 250)
###########################################################################################################


#######################4 CLASES #################################################################################3
# example with tiger mosquito and others images
#image_dir_train <- "D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/FRANCESC_LLIMONA_tfm_upc/tres_clases_train"
#dictionary<-c(tigre=1, culex=2, sin=3, plastic=4) #set classes and dictionary for classes
#image.trainimages.DL.algorithm_multiclass(dir.imag.training=image_dir_train, dictionary, size_foto=35, Do.saveRDS=F, Do.save.model=T, percent.CV=0.95, check.accuracy = T,  num.round = 250)
###########################################################################################################


## Set width and height for resizing images
#EBImage provides general purpose functionality for image processing and analysis. To install this package:

#source("https://bioconductor.org/biocLite.R")
#biocLite("EBImage")
#Read and display some examples from the training set:

#example_plas_image <- readImage(file.path(image_dir, "plastic_2.jpg"))
#display(example_plas_image)

#example_sin_image <- readImage(file.path(image_dir, "sin_1.jpg"))
#display(example_sin_image)
