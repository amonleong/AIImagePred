
###################old junio 2019####################################################
# split image
# prediccion salvando un modelo de deep learning salvado anteriormente
# cuenta todas las imagenes
#######################################################################

#proyecto medsealitter ue


#example
#directorio con las imagenes del training. Se han extraido sus caracteristicas
#train.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges"
#name.files.images<-c("class1_data.rds", "class2_data.rds")
#predict.test.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/test"
#tengo que hacer una funcion res.pred.DL.plastic.test para todos las clases y binaria


# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#example funcional solo para plastico
#directorio con las imagenes del training. Se han extraido sus caracteristicas
#train.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges"
#predict.test.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/test"
#name.files.images<-c("")
#################### test prediction ############################################################################
#prediction of images plastic
#res.pred.DL.plastic.test<- split.predict.count(train.images.dir, name.files.images, predict.test.images.dir, num.round = 150, n.div=5)
#res.pred.DL.plastic.test
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


############### split.predict.count ######################################
#funcion que hace todo
#preparada para el plastico: antes hay que salvar los ficheros con las caracteristicas con algorithm_DL_train_images()
# 1-split imagenes en 25 subimagenes
# 2-entrena un modelo a partir de unos ficheros que continenen las caracteristicas de las imagenes
# 3 predice las imagenes de 0-plastic 1-sin plastico
# 4-da un listado con las predicciones
#####################################################

#########################################################################################
#algorithm to train images in the DL algorithm and save its characteristics
#Binary classification
#########################################################################################
# Authomatic identification of images: read the train images, split the test image and predict the characteristic
#
# @param train.images.dir Directory with train images (only .rds files, one by characteristic)
# @param name.files.images Image files (By defect name.files.images<-c(""))
# @param predict.test.images.dir  Directory with test images (only .jpg images)
# @param n.div Split images in a different sub-images to classify the sub-images (By defect n.div=5 -> 25 subimages (5 by row and 5 by column))
# @param num.round Number of rounds to calculate the DL model in KERAS (By defect num.round = 150)
# @export
# #'
# @examples
# #Plastic identification ---------------------------------------------------
#
# #Directory of the files .rds with characteristics of the train images (.rds)
# train.images.dir<-"C:/Users/bootstrap3/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges"
#
# #Directory of the test images
# predict.test.images.dir<-"C:/Users/bootstrap3/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/test"
# name.files.images<-c("")
#
#  ################### test prediction ############################################################################
# library(AIImagePred)
# #prediction of test images with plastic (one image or 25 sub-images)
# res.pred.DL.plastic.test<- split.predict.count(train.images.dir, name.files.images, predict.test.images.dir, num.round = 150, n.div=5)
#
# #Results of the classification on the sub-images (0 PLASTICO, 1 SIN PLASTICO)
# res.pred.DL.plastic.test

#' @references
#' Daniel Falbel et al. 2017. Package Keras. R package <https://cran.r-project.org/web/packages/keras/keras.pdf>

split.predict.count<-
  function(train.images.dir,
           name.files.images,
           predict.test.images.dir,
           num.round = 150, n.div=5,
           my.opinion=NULL){


  #hace un splitting de las imagenes en un directorio en la raiz de las imagenes de test
  #dir.imag<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/test"
  #dir.imag.final<- "D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/test"

  #crea un directorio en dir.imag.final
  mainDir <- predict.test.images.dir
  subDir <- "outputDirectory"

  if (file.exists(subDir)){
    setwd(file.path(mainDir, subDir))
  } else {
    dir.create(file.path(mainDir, subDir))
    setwd(file.path(mainDir, subDir))

  }

  #split the images
  image.splitting.algorithm(dir.imag=mainDir, dir.imag.final=file.path(mainDir, subDir), n.div=n.div)

  #predict classes
  #directorio con las imagenes del training. Se han extraido sus caracteristicas
  #train.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges"
  #predict.test.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/test"
  #example:
  #################### test prediction ############################################################################
  #prediction of images plastic
  #res.pred.DL.plastic.test<- predict.class.DL.plastic(train.images.dir, predict.test.images.dir=file.path(mainDir, subDir), num.round = num.round)
  #num.round=10
  res.pred.DL.plastic.test<-
    predict.class.DL.plastic(
      train.images.dir,
      predict.test.images.dir=file.path(mainDir, subDir),
      num.round = num.round,
      my.opinion=NULL)


  #Table with results
  res.pred.DL.plastic.test
  a<-data.frame(res.pred.DL.plastic.test[1])
  #contar numero de imagenes de cada  tipo
  resultat.complet.imatge<- 100*table(a$predicted_labels)/length(a$predicted_labels)
  ################################################################################################################

  return(list(resultat.complet.imatge, res.pred.DL.plastic.test))

}
