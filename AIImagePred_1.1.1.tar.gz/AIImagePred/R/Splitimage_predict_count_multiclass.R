
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#example funcional solo para mosquitos tigre y no: 3 clases
#directorio con las imagenes del training. Se han extraido sus caracteristicas
#train.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/FRANCESC_LLIMONA_tfm_upc/tres_clases_train"
#predict.test.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/FRANCESC_LLIMONA_tfm_upc/test_imagen_mosquito_tigre"
#name.files.images<-c("")
#################### test prediction ############################################################################
#prediction of images mosquitos
#res.pred.DL.images.test<- split.predict.count.multiclass(train.images.dir, name.files.images, predict.test.images.dir, dictionary=c(tigre=1, culex=2, sin=3),  use.model=T, nom.model.saved = "prova_model.RData", num.round = 250, n.div=1)
#res.pred.DL.images.test
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


#########################################################################################
#algorithm to train images in the DL algorithm and save its characteristics
#Binary classification
#########################################################################################
#' Authomatic identification of images: read the train images, split the test image and predict the characteristic
#'
#' @param train.images.dir Directory with train images (only .rds files, one by characteristic)
#' @param name.files.images Image files (By defect name.files.images<-c(""))
#' @param predict.test.images.dir  Directory with test images (only .jpg images)
#' @param n.div Split images in a different sub-images to classify the sub-images (By defect n.div=5 -> 25 subimages (5 by row and 5 by column))
#' @param num.round Number of rounds to calculate the DL model in KERAS (By defect num.round = 150)
#' @export
#' #'
#' @examples
#' #Functional example only for tiger and culex mosquitoes and not-mosquitoes: 3 classes(CULEX, TIGER AND WITHOUT). GET IMAGE DIRECTORY "aedes_culex_clases_train" FROM MOSQUITO IN RESEARCHGATE https://www.researchgate.net/publication/335444848_mosquitoes_train_test_images_for_deep_learning_algorithm_Training_and_test_set
#' #directory with the images of the training. Its features have been extracted
#'
#'GET IMAGE DIRECTORY "aedes_culex_clases_train" FROM MOSQUITO IN RESEARCHGATE: https://www.researchgate.net/publication/335444848_mosquitoes_train_test_images_for_deep_learning_algorithm_Training_and_test_set
#'
#'###########################################################################################################
#'###########################################################################################################
#'#1. Obtain Prediction model (DL) with a training set already completed
#'###########################################################################################################
#'###########################################################################################################
#'
#'#######################3 CLASSES training #################################################################################3
#'## example with tiger and culex mosquitoes and others images
#'#' change directory if necessary !!!!!!!!!!!!
#'image_dir_train <- "D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/FRANCESC_LLIMONA_tfm_upc/aedes_culex_clases_train"
#'dictionary<-c(tigre=1, culex=2, sin=3) #set classes and dictionary for classes tiger, culex and others (no mosquitoes)
#'image.trainimages.DL.algorithm_multiclass(dir.imag.training=image_dir_train, dictionary, size_foto=25, Do.saveRDS=T, Do.save.model=T, percent.CV=0.9, check.accuracy = T,  num.round = 250)
#'###########################################################################################################
#'
#'#indica la accuracy:
#'
#' Results obtained for the training set:
#'
#'#[1] "Accuracy table: ----CROSS-VALIDATION( 90 %DATA)-----------------------------------"
#'#predicted_labels
#'#1  2  3
#'#1 31  0  0
#'#2  3 13  0
#'#3  0  0 15
#'#[1] "% accuracy total ( 90 %, Cross-validation)="
#'#[1] 0.9516129
#'#[1] "Accuracy table: ----CROSS-VALIDATION( 10 %DATA)-----------------------------------"
#'#predicted_labels
#'#1 2 3
#'#1 3 1 0
#'#2 0 1 0
#'#3 0 0 1
#'#[1] "% accuracy total ( 10 %, Cross-validation)="
#'#[1] 0.8333333
#'
#'
#'###########################################################################################################
#'###########################################################################################################
#'#2.Prediction (DL) using a training set (saved DL-model) already performed (Step-1)and with a test set in another directory
#'###########################################################################################################
#'###########################################################################################################

#' change directory if necessary !!!!!!!!!!!!
#' #In this directory you will find the DL-model of the training images saved previosuly:
#' train.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/FRANCESC_LLIMONA_tfm_upc/aedes_culex_clases_train"

#' #In this directory are the images to predict (See RESEARCHGATE) https://www.researchgate.net/publication/335444848_mosquitoes_train_test_images_for_deep_learning_algorithm_Training_and_test_set:
#' predict.test.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/FRANCESC_LLIMONA_tfm_upc/test_imagen_mosquito_tigre"

#' name.files.images<-c("")


#' #################### test prediction ####### DL-model saved = prova_model.RData #####################################################################
#' #prediction of images mosquitoes (images are not divided into multiple images)
#' res.pred.DL.images.test<- split.predict.count.multiclass(train.images.dir, name.files.images, predict.test.images.dir, dictionary=c(tigre=1, culex=2, sin=3),  use.model=T, nom.model.saved = "prova_model.RData", num.round = 250, n.div=1)
#' res.pred.DL.images.test
#'
#' Results of the ptest images prediction using DL
#'
#'#images_names predicted_labels names.dictionary.predicted_labels..
#'#1   culex11_c_1_r_1_nimag1.jpg                2                               culex
#'#2   culex11_c_1_r_1_nimag2.jpg                2                               culex
#'#3   culex51_c_1_r_1_nimag3.jpg                2                               culex
#'#4   culex91_c_1_r_1_nimag4.jpg                2                               culex
#'#5   sin_121_c_1_r_1_nimag5.jpg                3                                 sin
#'#6   sin_131_c_1_r_1_nimag6.jpg                3                                 sin
#'#7   sin_141_c_1_r_1_nimag7.jpg                3                                 sin
#'#8  tigre_1_c_1_r_1_nimag10.jpg                1                               tigre
#'#9  tigre_1_c_1_r_1_nimag11.jpg                1                               tigre
#'#10 tigre_1_c_1_r_1_nimag12.jpg                1                               tigre
#'#11 tigre_1_c_1_r_1_nimag13.jpg                1                               tigre
#'#12  tigre_1_c_1_r_1_nimag8.jpg                1                               tigre
#'#13  tigre_1_c_1_r_1_nimag9.jpg                2                               culex
#'
#'#[[2]][[2]]
#'#[1] "tigre" "culex" "sin"
#'
#'# The resuts ca be different to the above results






#' @references
#' CI Rodríguez-Casado, A Monleon-Getino, M Cubedo, M Ríos- Alcolea. 2017. A Priori Groups Based On Bhattacharyya Distance And Partitioning Around Medoids Algorithm (PAM) With Applications To Metagenomics
#' IOSR Journal of Mathematics 13 (3), 24-32
#'
#' Daniel Falbel et al. 2017. Package Keras. R package <https://cran.r-project.org/web/packages/keras/keras.pdf>

split.predict.count.multiclass<-  function(train.images.dir, name.files.images, predict.test.images.dir, size_foto=25, dictionary=c(plastic=0, sin=1), use.model=T, nom.model.saved = "prova_model.RData",
           num.round = 150, n.div=5, my.opinion=NULL){

   #n.div<-1
  #hace un splitting de las imagenes en un directorio en la raiz de las imagenes de test
  #dir.imag<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/test"
  #dir.imag.final<- "D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/test"

  #crea un directorio en dir.imag.final
  mainDir <- predict.test.images.dir
  subDir <- "outputDirectory"

  if (file.exists(subDir)){
    setwd(file.path(mainDir, subDir))
  } else {
    dir.create(file.path(mainDir, subDir))
    setwd(file.path(mainDir, subDir))

  }

  #split the images
  image.splitting.algorithm(dir.imag=mainDir, dir.imag.final=file.path(mainDir, subDir), n.div=n.div)

  #predict classes
  #directorio con las imagenes del training. Se han extraido sus caracteristicas
  #train.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges"
  #predict.test.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/test"
  #example:
  #################### test prediction ############################################################################
  #prediction of images plastic
  #res.pred.DL.plastic.test<- predict.class.DL.plastic(train.images.dir, predict.test.images.dir=file.path(mainDir, subDir), num.round = num.round)
  #num.round=10
  #res.pred.DL.plastic.test<-  predict.class.DL.binary(train.images.dir,
  #    predict.test.images.dir=file.path(mainDir, subDir), dictionary=dictionary, num.round = num.round,
  #    my.opinion=NULL)

  res.pred.DL.plastic.test<-  predict.class.DL.multiclass(train.images.dir,
                                                      predict.test.images.dir=file.path(mainDir, subDir), size_foto, dictionary=dictionary, use.model=T, nom.model.saved = "prova_model.RData", num.round = num.round,
                                                      my.opinion=NULL)

  #Table with results
  res.pred.DL.plastic.test
  a<-data.frame(res.pred.DL.plastic.test[1])
  #contar numero de imagenes de cada  tipo
  resultat.complet.imatge<- 100*table(a$predicted_labels)/length(a$predicted_labels)
  ################################################################################################################

  return(list(resultat.complet.imatge, res.pred.DL.plastic.test))

}
