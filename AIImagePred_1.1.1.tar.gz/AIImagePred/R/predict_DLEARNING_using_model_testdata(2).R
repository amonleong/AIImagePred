
############# creo que es una funcion old experimental junio 2019 #######################
#######################################################################
# prediccion salvando un modelo de deep learning salvado anteriormente
#######################################################################

#proyecto medsealitter ue


#example
#directorio con las imagenes del training. Se han extraido sus caracteristicas
#train.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges"
#predict.test.images.dir<-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/test"
#example:
#################### test prediction ############################################################################
#prediction of images plastic
#res.pred.DL.plastic.test<- predict.class.DL.plastic(train.images.dir, predict.test.images.dir, num.round = 50)
#Table with results
#res.pred.DL.plastic.test
#a<-data.frame(res.pred.DL.plastic.test[1])
#contar numero de imagenes de cada  tipo
#100*table(a$predicted_labels)/length(a$predicted_labels)
################################################################################################################


#my.name <- readline(prompt="Enter name: ")
#my.age <- readline(prompt="Enter age: ")
# convert character into integer
#my.age <- as.integer(my.age)
#print(paste("Hi,", my.name, "next year you will be", my.age+1, "years old."))


 # image_dir <-"D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/test"


#funcion para predecir plasticos a partir de unas imagenes divididas en 0-plastic, 1-non.plastic
predict.class.DL.plastic<- function(train.images.dir, predict.test.images.dir, num.round = 150,
                                    my.opinion=NULL){

  #parametros del modelo, es de la matriz de trabajo de 25 x 25 pixeles
  size_foto<-25


  #setwd("E:/intercambioconservidorBIOST3/odei/Plastics/train")
  #setwd("D:/Dropbox_Toni/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges")
  setwd(train.images.dir)
  #imagenes del training donde se han extraido sus caracteristicas y son matrices B/N 25*25
  plastic_data<-readRDS("plastic.rds", refhook = NULL)
  sin_data<-readRDS("sin.rds", refhook = NULL)

  library(caret)
  ## Bind rows in a single dataset
  set.seed(1078) #fix random seed
  complete_set <- rbind(plastic_data, sin_data)
  ## test/training partitions (80% training, 20% test)
  training_index <- createDataPartition(complete_set$label, p = .9, times = 1)
  training_index <- unlist(training_index)
  train_set <- complete_set[training_index,]
  dim(train_set)
  ## [1] 22500   785
  test_set <- complete_set[-training_index,]
  dim(test_set)
  ## [1] 2500  785
  #Reshape the data into a proper format required by the model:

  ## Fix train and test datasets
  train_data <- data.matrix(train_set)
  train_x <- t(train_data[, -1])
  train_y <- train_data[,1]
  train_array <- train_x
  dim(train_array) <- c(size_foto, size_foto, 1, ncol(train_x))

  test_data <- data.matrix(test_set)
  test_x <- t(test_set[,-1])
  test_y <- test_set[,1]
  test_array <- test_x
  dim(test_array) <- c(size_foto, size_foto, 1, ncol(test_x))
  #Training the model:

  library(mxnet)
  ## Model
  mx_data <- mx.symbol.Variable('data')
  ## 1st convolutional layer 5x5 kernel and 20 filters.
  conv_1 <- mx.symbol.Convolution(data = mx_data, kernel = c(5, 5), num_filter = 50)
  tanh_1 <- mx.symbol.Activation(data = conv_1, act_type = "tanh")
  pool_1 <- mx.symbol.Pooling(data = tanh_1, pool_type = "max", kernel = c(2, 2), stride = c(2,2 ))
  ## 2nd convolutional layer 5x5 kernel and 50 filters.
  conv_2 <- mx.symbol.Convolution(data = pool_1, kernel = c(5,5), num_filter = 50)
  tanh_2 <- mx.symbol.Activation(data = conv_2, act_type = "tanh")
  pool_2 <- mx.symbol.Pooling(data = tanh_2, pool_type = "max", kernel = c(2, 2), stride = c(2, 2))
  ## 1st fully connected layer
  flat <- mx.symbol.Flatten(data = pool_2)
  fcl_1 <- mx.symbol.FullyConnected(data = flat, num_hidden = 100)
  tanh_3 <- mx.symbol.Activation(data = fcl_1, act_type = "tanh")
  ## 2nd fully connected layer
  fcl_2 <- mx.symbol.FullyConnected(data = tanh_3, num_hidden = 10)
  ## Output
  NN_model <- mx.symbol.SoftmaxOutput(data = fcl_2)

  ## Set seed for reproducibility
  mx.set.seed(196)

  ## Device used. Sadly not the GPU :-(
  device <- mx.cpu()

  print("Calculating the DL model. Please patient!!!!!!!........")
  ## Train on 1200 samples
  #num.round=250
  model <- mx.model.FeedForward.create(NN_model, X = train_array, y = train_y,
                                       ctx = mx.cpu(),
                                       num.round = num.round,
                                       momentum = 0.9,
                                       array.batch.size = 100,
                                       learning.rate = 0.025,
                                       wd = 0.00001,
                                       eval.metric =mx.metric.accuracy,
                                       epoch.end.callback = mx.callback.log.train.metric(100))

  #you can save the model using: https://stackoverflow.com/questions/43517960/how-to-save-a-model-when-using-mxnet
  #model <- mx.model.FeedForward.create(NN_model, X = train_array, y = train_y,
  #                                     ctx = device,
  #                                     num.round = 150,
  #                                     array.batch.size = 100,
  #                                     learning.rate = 0.05,
  #                                     momentum = 0.9,
  #                                     wd = 0.00001,
  #                                     eval.metric = mx.metric.accuracy,
  #                                     epoch.end.callback=mx.callback.save.checkpoint("model_prefix"),
  #                                     batch.end.callback=mx.callback.log.speedometer(batch.size, frequency = 100))

  #model <- mx.model.FeedForward.create(NN_model, X = train_array, y = train_y,
  #                                     ctx = mx.cpu(),
  #                                     num.round = 5,
  #                                    array.batch.size = 60,
  #                                    optimizer = "rmsprop",
  #                                    verbose = TRUE,
  #                                    array.layout = "rowmajor",
  #                                    batch.end.callback = NULL,
  #                                    epoch.end.callback = NULL)

  ##pere lopez: como salvar y recuperar el modelo
  ## desar
  #modelr <- mx.serialize(model)
  #save(modelr, file="~/prova/prova_model.RData")

  ## carregar
  #load("~/prova/prova_model.RData", verbose=TRUE)
  #model <- mx.unserialize(modelr)


  ## train set
  predict_probs <- predict(model, train_array)
  predicted_labels <- max.col(t(predict_probs)) - 1
  table(train_data[, 1], predicted_labels)
  #accuracy
  accuracy.modelDL<- sum(diag(table(train_data[, 1], predicted_labels)))/sum(table(train_data[, 1], predicted_labels))
  print(paste("Accuracy DL model train set= ", round(accuracy.modelDL,3), sep =""))



  ## Test test set
  predict_probs <- predict(model, test_array)
  predicted_labels <- max.col(t(predict_probs)) - 1
  table(test_data[, 1], predicted_labels)
  #accuracy
  accuracy.modelDL<- sum(diag(table(test_data[, 1], predicted_labels)))/sum(table(test_data[, 1], predicted_labels))
  print(paste("Accuracy DL model test set (at random 10%)= ", round(accuracy.modelDL,3), sep =""))

  #if (is.null(my.opinion)) {
  #  my.opinion <- readline(prompt="Are you happy with the DL-Model-accuracy: (Y/N) ")}
  #if (my.opinion=="N"){
  #  #print("please repeat again the function")
  #  stop('Please repeat again the function! \n\n')
  #}
  #if (my.opinion=="Y"){
  #  print("OK. Let' s go to proceed with the test images....................")
  #  print(".................................................................")
  #}

  ###############
  # test
  ###############

  #############################################################################
  # identificacion de imagenes en base a un modelo de deep-learning
  #############################################################################

  ##############################################################
  # conjunto de test - TEST - TEST - TEST IMAGENES A PREDECIR
  ##############################################################

  #a partir de aqui
  library(mxnet)
  ## Directory for images
  image_dir <-predict.test.images.dir
  #image_dir <-"C:/Users/bootstrap3/Dropbox/otros analisis estadisticos 2015/MEDSEALITTER_2018_ODEI_MORGANA/app_imatges/test"
  #image_dir <-"E:/intercambioconservidorBIOST3/odei/Plastics/test"




  ## Set width and height for resizing images
  #EBImage provides general purpose functionality for image processing and analysis. To install this package:

  #source("https://bioconductor.org/biocLite.R")
  #biocLite("EBImage")
  #Read and display some examples from the training set:

  #example_plas_image <- readImage(file.path(image_dir, "plastic_2.jpg"))
  #display(example_plas_image)

  #example_sin_image <- readImage(file.path(image_dir, "sin_1.jpg"))
  #display(example_sin_image)



  library(EBImage)
  #As a quick example, I will use EBImage to resize the images to 28×28 and turn them into greyscale so that I can load them into R easily. To do so, I will use a function to process the images for cats and dogs separately. Each image will be turned into a vector of length 784, with each element representing the value in a pixel.
  #size_foto<- 25 #25 filas de pixeles
  width <- size_foto
  height <- size_foto
  ## pbapply is a library to add progress bar *apply functions
  ## pblapply will replace lapply
  library(pbapply)
  extract_feature_test <- function(dir_path, width, height, is_plastic = TRUE, add_label = TRUE) {
    img_size <- width*height
    ## List images in path
    images_names <- list.files(dir_path)
    #if (add_label) {
      ## Select only cats or dogs images
    #  images_names <- images_names[grepl(ifelse(is_plastic, "plastic", "sin"), images_names)]
      ## Set label, plastic = 0, sin = 1
      label <- 0   #ifelse(is_plastic, 0, 1)
    #}
    print(paste("Start processing", length(images_names), "images"))
    ## This function will resize an image, turn it into greyscale
    feature_list <- pblapply(images_names, function(imgname) {
      ## Read image
      img <- readImage(file.path(dir_path, imgname))
      ## Resize image
      img_resized <- resize(img, w = width, h = height)
      ## Set to grayscale
      grayimg <- channel(img_resized, "gray")
      ## Get the image as a matrix
      img_matrix <- grayimg@.Data
      ## Coerce to a vector
      img_vector <- as.vector(t(img_matrix))
      return(img_vector)
    })
    ## bind the list of vector into matrix
    feature_matrix <- do.call(rbind, feature_list)
    feature_matrix <- as.data.frame(feature_matrix)
    ## Set names
    names(feature_matrix) <- paste0("pixel", c(1:img_size))
    #if (add_label) {
      ## Add label
      feature_matrix <- cbind(label = label, feature_matrix)
    #}
    return(feature_matrix)
  }


  #Process plastic and dog images separately and save them into data.frame
  #todas las imagenes deberan nombrarse como plastic == 0

  print("Read the test images........")
  plastic_data <- extract_feature_test(dir_path = image_dir, width = width, height = height,add_label = T) #SIEMPRE SE PONE COMO ETIQUETA A 1
  #plastic_data[1:10,1:10]
  #sin_data <- extract_feature(dir_path = image_dir, width = width, height = height, is_plastic = FALSE)
  #dim(plastic_data)
  #str(plastic_data)
  ## [1] 12500   785
  #dim(sin_data)
  ## [1] 12500   785
  #Save the data just in case:

  #saveRDS(plastic_data, "plastic.rds")
  #saveRDS(sin_data, "sin.rds")
  #3 Model Training
  #Data partitions: randomly split 90% of data into training set with equal weights for cats and dogs, and the rest 10% will be used as the test set.

  #si se han salvado-llamar a los ficheros .rds
  #setwd("E:/intercambioconservidorBIOST3/odei/Plastics/train")
  #plastic_data<-readRDS("plastic.rds", refhook = NULL)
  #sin_data<-readRDS("sin.rds", refhook = NULL)
  library(caret)
  ## Bind rows in a single dataset
  complete_set <- rbind(plastic_data)
  ## test/training partitions
  #training_index <- createDataPartition(complete_set$label, p = .8, times = 1)
  #training_index <- unlist(training_index)
  #train_set <- complete_set[training_index,]
  #dim(train_set)
  ## [1] 22500   785
  test_set <- complete_set
  dim(test_set)
  ## [1] 2500  785
  #Reshape the data into a proper format required by the model:

  ## Fix train and test datasets
  #train_data <- data.matrix(train_set)
  #train_x <- t(train_data[, -1])
  #train_y <- train_data[,1]
  #train_array <- train_x
  #dim(train_array) <- c(size_foto, size_foto, 1, ncol(train_x))

  test_data <- data.matrix(test_set)
  test_x <- t(test_set[,-1])
  test_y <- test_set[,1]
  test_array <- test_x
  dim(test_array) <- c(size_foto, size_foto, 1, ncol(test_x))
  #Training the model:
  library(mxnet)



  ##############prediccion con modelo Deep-learning


  #ficheros de tipo
  #model <- readRDS("final_model.rds")

  #View(test_array)
  #dim(test_array)

  ################################################################################
   ## AQUI HACE LA PREDICCION DE LAS IMAGENES (0 = PLASTIC, 1 = SIN PLASTIC)
  predict_probs <- predict(model, test_array)
  predicted_labels <- max.col(t(predict_probs)) - 1
  images_names <- list.files(image_dir)

  results.clase.images.predicted<-data.frame(images_names, predicted_labels)
  #################################################################################
  #table(test_data[, 1], predicted_labels)
  ##    predicted_labels
  ##        0    1
  ##   0 1099  151
  ##   1  470  780
  #sum(diag(table(test_data[, 1], predicted_labels)))/sum(table(test_data[, 1], predicted_labels))
  ## [1] 0.7516
  #The model reaches 75% accuracy on the test set. The score is of course a bit mediocre, but it can be easily improved by tuning the model, using more pixels and RGB representation.

  #save the model
  # table(test_data[, 1], predicted_labels)
  #predicted_labels
  #0  1
  #0  9  3
  #1  4 28
  #> ##    predicted_labels
  #  > ##        0    1
  #  > ##   0 1099  151
  #  > ##   1  470  780
  #  > sum(diag(table(test_data[, 1], predicted_labels)))/sum(table(test_data[, 1], predicted_labels))
  #[1] 0.8409091

  #save(model, file = "model_deep.RData")
  # To load the data again
  #load("model_deep.RData")





  #entregara una lista con los resultados
  return(list(results.clase.images.predicted,accuracy.modelDL, "class: plastic = 0, sin = 1"))

}
##########################################################################
# se ejecuta el modelo y se carga en memoria: hay algun problema con ello
##########################################################################

